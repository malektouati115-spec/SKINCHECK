from flask import Flask, render_template, request, redirect, session, flash
import os
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import mysql.connector

app = Flask(__name__)
app.secret_key = "secret"

UPLOAD_FOLDER = "static/uploads/"
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
model = load_model(os.path.join(BASE_DIR, "model", "vgg16_malignant_benign.h5"))

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="skin_cancer_db"
)
cursor = db.cursor(dictionary=True)

# --- LOGIN ---
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = request.form["username"]
        pwd  = request.form["password"]
        cursor.execute("SELECT * FROM users WHERE username=%s AND password=%s", (user, pwd))
        result = cursor.fetchone()
        if result:
            session["user"]    = user
            session["user_id"] = result["id"]
            return redirect("/dashboard")
        else:
            flash("Nom d'utilisateur ou mot de passe incorrect.", "danger")
    return render_template("login.html")

# --- REGISTER ---
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        confirm  = request.form["confirm"]
        if password != confirm:
            flash("Les mots de passe ne correspondent pas.", "danger")
            return render_template("register.html")
        cursor.execute("SELECT * FROM users WHERE username=%s", (username,))
        if cursor.fetchone():
            flash("Ce nom d'utilisateur est déjà pris.", "warning")
            return render_template("register.html")
        cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
        db.commit()
        flash("Compte créé avec succès ! Vous pouvez vous connecter.", "success")
        return redirect("/")
    return render_template("register.html")

# --- DASHBOARD ---
@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect("/")
    uid = session["user_id"]
    # Stats uniquement pour ce docteur
    cursor.execute("SELECT COUNT(*) as total FROM patients WHERE doctor_id=%s", (uid,))
    total = cursor.fetchone()["total"]
    cursor.execute("SELECT COUNT(*) as mal FROM patients WHERE result='Malignant' AND doctor_id=%s", (uid,))
    malignant = cursor.fetchone()["mal"]
    benign = total - malignant
    return render_template("dashboard.html", total=total, malignant=malignant, benign=benign, user=session["user"])

# --- PREDICT ---
@app.route("/predict", methods=["GET", "POST"])
def predict():
    if "user" not in session:
        return redirect("/")
    if request.method == "POST":
        try:
            name = request.form["name"]
            age  = request.form["age"]
            file = request.files["image"]
            if file.filename == "":
                flash("Veuillez choisir une image.", "warning")
                return redirect("/predict")
            path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(path)
            img = image.load_img(path, target_size=(224, 224))
            img_array = image.img_to_array(img) / 255.0
            img_array = np.expand_dims(img_array, axis=0)
            pred   = model.predict(img_array)[0][0]
            result = "Malignant" if pred > 0.5 else "Benign"
            # Enregistrer avec l'ID du docteur connecté
            cursor.execute("""
                INSERT INTO patients (name, age, result, probability, image_path, doctor_id)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (name, age, result, float(pred), path, session["user_id"]))
            db.commit()
            return render_template("result.html",
                                   result=result,
                                   prob=round(pred * 100, 2),
                                   img=path,
                                   name=name,
                                   age=age)
        except Exception as e:
            flash(f"Erreur : {str(e)}", "danger")
            return redirect("/predict")
    return render_template("predict.html")

# --- PATIENTS — uniquement ceux du docteur connecté ---
@app.route("/patients")
def patients():
    if "user" not in session:
        return redirect("/")
    cursor.execute(
        "SELECT * FROM patients WHERE doctor_id=%s ORDER BY created_at DESC",
        (session["user_id"],)
    )
    data = cursor.fetchall()
    return render_template("patients.html", patients=data)

# --- LOGOUT ---
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)
